import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcrypt";
import session from "express-session";
import Stripe from "stripe";
import { storage } from "./storage";
import { 
  loginSchema, 
  registerSchema, 
  propertySearchSchema,
  insertPropertySchema,
  insertBookingSchema,
  insertReviewSchema,
  insertMessageSchema
} from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

declare module 'express-session' {
  interface SessionData {
    userId?: string;
    userRole?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'fallback-secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days
    }
  }));

  // Auth middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  const requireRole = (roles: string[]) => (req: any, res: any, next: any) => {
    if (!req.session.userRole || !roles.includes(req.session.userRole)) {
      return res.status(403).json({ message: "Insufficient permissions" });
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Set session
      req.session.userId = user.id;
      req.session.userRole = user.role;

      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      req.session.userRole = user.role;

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Property routes
  app.get("/api/properties", async (req, res) => {
    try {
      const filters = propertySearchSchema.parse(req.query);
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = (page - 1) * limit;

      const result = await storage.searchProperties({
        ...filters,
        limit,
        offset
      });

      res.json({
        properties: result.properties,
        total: result.total,
        page,
        totalPages: Math.ceil(result.total / limit)
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/properties/featured", async (req, res) => {
    try {
      const properties = await storage.getFeaturedProperties(6);
      res.json({ properties });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/properties/:id", async (req, res) => {
    try {
      const property = await storage.getProperty(req.params.id);
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }
      res.json({ property });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/properties", requireAuth, requireRole(['owner', 'admin']), async (req, res) => {
    try {
      const propertyData = insertPropertySchema.parse(req.body);
      const property = await storage.createProperty({
        ...propertyData,
        ownerId: req.session.userId!
      });
      res.json({ property });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/properties/:id", requireAuth, async (req, res) => {
    try {
      const property = await storage.getProperty(req.params.id);
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }

      // Check ownership or admin role
      if (property.ownerId !== req.session.userId && req.session.userRole !== 'admin') {
        return res.status(403).json({ message: "Not authorized to update this property" });
      }

      const propertyData = insertPropertySchema.partial().parse(req.body);
      const updatedProperty = await storage.updateProperty(req.params.id, propertyData);
      res.json({ property: updatedProperty });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/properties/:id", requireAuth, async (req, res) => {
    try {
      const property = await storage.getProperty(req.params.id);
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }

      // Check ownership or admin role
      if (property.ownerId !== req.session.userId && req.session.userRole !== 'admin') {
        return res.status(403).json({ message: "Not authorized to delete this property" });
      }

      await storage.deleteProperty(req.params.id);
      res.json({ message: "Property deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Property reviews
  app.get("/api/properties/:id/reviews", async (req, res) => {
    try {
      const reviews = await storage.getReviewsByProperty(req.params.id);
      res.json({ reviews });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/properties/:id/reviews", requireAuth, requireRole(['student']), async (req, res) => {
    try {
      const reviewData = insertReviewSchema.parse(req.body);
      const review = await storage.createReview({
        ...reviewData,
        propertyId: req.params.id,
        studentId: req.session.userId!
      });
      res.json({ review });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Booking routes
  app.get("/api/bookings", requireAuth, async (req, res) => {
    try {
      let bookings;
      if (req.session.userRole === 'student') {
        bookings = await storage.getBookingsByStudent(req.session.userId!);
      } else if (req.session.userRole === 'owner') {
        // Get bookings for owner's properties
        const properties = await storage.getPropertiesByOwner(req.session.userId!);
        const allBookings = await Promise.all(
          properties.map(p => storage.getBookingsByProperty(p.id))
        );
        bookings = allBookings.flat();
      } else {
        // Admin can see all bookings - implement pagination if needed
        bookings = [];
      }
      
      res.json({ bookings });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/bookings/:id", requireAuth, async (req, res) => {
    try {
      const booking = await storage.getBooking(req.params.id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }

      // Check authorization
      if (booking.studentId !== req.session.userId && req.session.userRole !== 'admin') {
        const property = await storage.getProperty(booking.propertyId);
        if (!property || property.ownerId !== req.session.userId) {
          return res.status(403).json({ message: "Not authorized to view this booking" });
        }
      }

      res.json({ booking });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/bookings", requireAuth, requireRole(['student']), async (req, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking({
        ...bookingData,
        studentId: req.session.userId!
      });
      res.json({ booking });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/bookings/:id", requireAuth, async (req, res) => {
    try {
      const booking = await storage.getBooking(req.params.id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }

      // Check authorization
      let canUpdate = false;
      if (req.session.userRole === 'admin') {
        canUpdate = true;
      } else if (req.session.userRole === 'student' && booking.studentId === req.session.userId) {
        canUpdate = true;
      } else if (req.session.userRole === 'owner') {
        const property = await storage.getProperty(booking.propertyId);
        if (property && property.ownerId === req.session.userId) {
          canUpdate = true;
        }
      }

      if (!canUpdate) {
        return res.status(403).json({ message: "Not authorized to update this booking" });
      }

      const bookingData = insertBookingSchema.partial().parse(req.body);
      const updatedBooking = await storage.updateBooking(req.params.id, bookingData);
      res.json({ booking: updatedBooking });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Payment routes
  app.post("/api/create-payment-intent", requireAuth, async (req, res) => {
    try {
      const { amount, bookingId } = req.body;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          bookingId,
          userId: req.session.userId!
        }
      });

      // Create payment record
      await storage.createPayment({
        bookingId,
        amount: amount.toString(),
        stripePaymentIntentId: paymentIntent.id,
        status: "pending"
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  app.post("/api/payments/:id/confirm", requireAuth, async (req, res) => {
    try {
      const payment = await storage.getPayment(req.params.id);
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }

      const updatedPayment = await storage.updatePayment(req.params.id, {
        status: "in_escrow",
        paidAt: new Date()
      });

      res.json({ payment: updatedPayment });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Chat routes
  app.get("/api/chats", requireAuth, async (req, res) => {
    try {
      const chats = await storage.getChatsByUser(req.session.userId!);
      res.json({ chats });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/chats/:id/messages", requireAuth, async (req, res) => {
    try {
      const chat = await storage.getChat(req.params.id);
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }

      // Check authorization
      if (chat.studentId !== req.session.userId && chat.ownerId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized to view this chat" });
      }

      const messages = await storage.getMessagesByChat(req.params.id);
      res.json({ messages });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/chats/:id/messages", requireAuth, async (req, res) => {
    try {
      const chat = await storage.getChat(req.params.id);
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }

      // Check authorization
      if (chat.studentId !== req.session.userId && chat.ownerId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized to send messages in this chat" });
      }

      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage({
        ...messageData,
        chatId: req.params.id,
        senderId: req.session.userId!
      });

      res.json({ message });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Dashboard stats (admin only)
  app.get("/api/admin/stats", requireAuth, requireRole(['admin']), async (req, res) => {
    try {
      // This would require additional database queries for stats
      // For now, return placeholder data
      res.json({
        totalUsers: 0,
        totalProperties: 0,
        totalBookings: 0,
        totalRevenue: 0
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
