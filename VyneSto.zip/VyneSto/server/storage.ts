import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, and, like, gte, lte, desc, asc, or, count, avg } from "drizzle-orm";
import { 
  users, properties, bookings, payments, reviews, chats, messages,
  type User, type InsertUser, type Property, type InsertProperty,
  type Booking, type InsertBooking, type Payment, type InsertPayment,
  type Review, type InsertReview, type Chat, type InsertChat,
  type Message, type InsertMessage
} from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

const sql = neon(process.env.DATABASE_URL);
const db = drizzle(sql);

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User>;
  updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;

  // Property operations
  getProperty(id: string): Promise<Property | undefined>;
  getPropertiesByOwner(ownerId: string): Promise<Property[]>;
  searchProperties(filters: {
    location?: string;
    budgetClass?: string;
    propertyType?: string;
    minPrice?: number;
    maxPrice?: number;
    amenities?: string[];
    limit?: number;
    offset?: number;
  }): Promise<{ properties: Property[]; total: number }>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: string, property: Partial<InsertProperty>): Promise<Property>;
  deleteProperty(id: string): Promise<void>;
  getFeaturedProperties(limit?: number): Promise<Property[]>;
  updatePropertyRating(propertyId: string): Promise<void>;

  // Booking operations
  getBooking(id: string): Promise<Booking | undefined>;
  getBookingsByStudent(studentId: string): Promise<Booking[]>;
  getBookingsByProperty(propertyId: string): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: string, booking: Partial<InsertBooking>): Promise<Booking>;
  deleteBooking(id: string): Promise<void>;

  // Payment operations
  getPayment(id: string): Promise<Payment | undefined>;
  getPaymentsByBooking(bookingId: string): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: string, payment: Partial<InsertPayment>): Promise<Payment>;

  // Review operations
  getReview(id: string): Promise<Review | undefined>;
  getReviewsByProperty(propertyId: string): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: string, review: Partial<InsertReview>): Promise<Review>;
  deleteReview(id: string): Promise<void>;

  // Chat operations
  getChat(id: string): Promise<Chat | undefined>;
  getChatsByUser(userId: string): Promise<Chat[]>;
  createChat(chat: InsertChat): Promise<Chat>;
  updateChat(id: string, chat: Partial<InsertChat>): Promise<Chat>;

  // Message operations
  getMessage(id: string): Promise<Message | undefined>;
  getMessagesByChat(chatId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: string): Promise<Message>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: string, user: Partial<InsertUser>): Promise<User> {
    const result = await db.update(users).set(user).where(eq(users.id, id)).returning();
    return result[0];
  }

  async updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const updateData: any = { stripeCustomerId };
    if (stripeSubscriptionId) {
      updateData.stripeSubscriptionId = stripeSubscriptionId;
    }
    const result = await db.update(users).set(updateData).where(eq(users.id, id)).returning();
    return result[0];
  }

  // Property operations
  async getProperty(id: string): Promise<Property | undefined> {
    const result = await db.select().from(properties).where(eq(properties.id, id)).limit(1);
    return result[0];
  }

  async getPropertiesByOwner(ownerId: string): Promise<Property[]> {
    return await db.select().from(properties).where(eq(properties.ownerId, ownerId)).orderBy(desc(properties.createdAt));
  }

  async searchProperties(filters: {
    location?: string;
    budgetClass?: string;
    propertyType?: string;
    minPrice?: number;
    maxPrice?: number;
    amenities?: string[];
    limit?: number;
    offset?: number;
  }): Promise<{ properties: Property[]; total: number }> {
    let query = db.select().from(properties).where(eq(properties.status, "approved"));
    let countQuery = db.select({ count: count() }).from(properties).where(eq(properties.status, "approved"));

    const conditions = [];

    if (filters.location) {
      const locationCondition = or(
        like(properties.city, `%${filters.location}%`),
        like(properties.address, `%${filters.location}%`),
        like(properties.country, `%${filters.location}%`)
      );
      conditions.push(locationCondition);
    }

    if (filters.budgetClass) {
      conditions.push(eq(properties.budgetClass, filters.budgetClass as any));
    }

    if (filters.propertyType) {
      conditions.push(eq(properties.type, filters.propertyType as any));
    }

    if (filters.minPrice) {
      conditions.push(gte(properties.pricePerMonth, filters.minPrice.toString()));
    }

    if (filters.maxPrice) {
      conditions.push(lte(properties.pricePerMonth, filters.maxPrice.toString()));
    }

    if (conditions.length > 0) {
      const combinedConditions = and(...conditions);
      query = query.where(combinedConditions);
      countQuery = countQuery.where(combinedConditions);
    }

    const propertiesResult = await query
      .orderBy(desc(properties.rating), desc(properties.createdAt))
      .limit(filters.limit || 20)
      .offset(filters.offset || 0);

    const totalResult = await countQuery;

    return {
      properties: propertiesResult,
      total: totalResult[0].count as number
    };
  }

  async createProperty(property: InsertProperty): Promise<Property> {
    const result = await db.insert(properties).values(property).returning();
    return result[0];
  }

  async updateProperty(id: string, property: Partial<InsertProperty>): Promise<Property> {
    const result = await db.update(properties).set(property).where(eq(properties.id, id)).returning();
    return result[0];
  }

  async deleteProperty(id: string): Promise<void> {
    await db.delete(properties).where(eq(properties.id, id));
  }

  async getFeaturedProperties(limit: number = 6): Promise<Property[]> {
    return await db.select().from(properties)
      .where(and(eq(properties.status, "approved"), eq(properties.isAvailable, true)))
      .orderBy(desc(properties.rating))
      .limit(limit);
  }

  async updatePropertyRating(propertyId: string): Promise<void> {
    const avgRating = await db.select({ 
      avg: avg(reviews.rating),
      count: count(reviews.id)
    })
    .from(reviews)
    .where(eq(reviews.propertyId, propertyId));

    if (avgRating[0]) {
      await db.update(properties)
        .set({
          rating: avgRating[0].avg?.toString() || "0.00",
          reviewCount: avgRating[0].count
        })
        .where(eq(properties.id, propertyId));
    }
  }

  // Booking operations
  async getBooking(id: string): Promise<Booking | undefined> {
    const result = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
    return result[0];
  }

  async getBookingsByStudent(studentId: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.studentId, studentId)).orderBy(desc(bookings.createdAt));
  }

  async getBookingsByProperty(propertyId: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.propertyId, propertyId)).orderBy(desc(bookings.createdAt));
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const result = await db.insert(bookings).values(booking).returning();
    return result[0];
  }

  async updateBooking(id: string, booking: Partial<InsertBooking>): Promise<Booking> {
    const result = await db.update(bookings).set(booking).where(eq(bookings.id, id)).returning();
    return result[0];
  }

  async deleteBooking(id: string): Promise<void> {
    await db.delete(bookings).where(eq(bookings.id, id));
  }

  // Payment operations
  async getPayment(id: string): Promise<Payment | undefined> {
    const result = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
    return result[0];
  }

  async getPaymentsByBooking(bookingId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.bookingId, bookingId)).orderBy(desc(payments.createdAt));
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const result = await db.insert(payments).values(payment).returning();
    return result[0];
  }

  async updatePayment(id: string, payment: Partial<InsertPayment>): Promise<Payment> {
    const result = await db.update(payments).set(payment).where(eq(payments.id, id)).returning();
    return result[0];
  }

  // Review operations
  async getReview(id: string): Promise<Review | undefined> {
    const result = await db.select().from(reviews).where(eq(reviews.id, id)).limit(1);
    return result[0];
  }

  async getReviewsByProperty(propertyId: string): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.propertyId, propertyId)).orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const result = await db.insert(reviews).values(review).returning();
    // Update property rating after creating review
    await this.updatePropertyRating(review.propertyId);
    return result[0];
  }

  async updateReview(id: string, review: Partial<InsertReview>): Promise<Review> {
    const result = await db.update(reviews).set(review).where(eq(reviews.id, id)).returning();
    if (result[0] && review.rating) {
      await this.updatePropertyRating(result[0].propertyId);
    }
    return result[0];
  }

  async deleteReview(id: string): Promise<void> {
    const review = await this.getReview(id);
    await db.delete(reviews).where(eq(reviews.id, id));
    if (review) {
      await this.updatePropertyRating(review.propertyId);
    }
  }

  // Chat operations
  async getChat(id: string): Promise<Chat | undefined> {
    const result = await db.select().from(chats).where(eq(chats.id, id)).limit(1);
    return result[0];
  }

  async getChatsByUser(userId: string): Promise<Chat[]> {
    return await db.select().from(chats)
      .where(or(eq(chats.studentId, userId), eq(chats.ownerId, userId)))
      .orderBy(desc(chats.lastMessageAt));
  }

  async createChat(chat: InsertChat): Promise<Chat> {
    const result = await db.insert(chats).values(chat).returning();
    return result[0];
  }

  async updateChat(id: string, chat: Partial<InsertChat>): Promise<Chat> {
    const result = await db.update(chats).set(chat).where(eq(chats.id, id)).returning();
    return result[0];
  }

  // Message operations
  async getMessage(id: string): Promise<Message | undefined> {
    const result = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
    return result[0];
  }

  async getMessagesByChat(chatId: string): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.chatId, chatId)).orderBy(asc(messages.createdAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const result = await db.insert(messages).values(message).returning();
    
    // Update chat's last message
    await this.updateChat(message.chatId, {
      lastMessage: message.content,
      lastMessageAt: new Date()
    });
    
    return result[0];
  }

  async markMessageAsRead(id: string): Promise<Message> {
    const result = await db.update(messages).set({ isRead: true }).where(eq(messages.id, id)).returning();
    return result[0];
  }
}

export const storage = new DatabaseStorage();
