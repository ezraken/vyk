// This file is kept for reference but we're using Drizzle directly
// as per the Supabase blueprint instructions
export const supabase = null;
